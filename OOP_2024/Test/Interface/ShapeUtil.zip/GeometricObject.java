public interface GeometricObject {
    
    public double getArea();

    public double getPerimeter();

    public String getInfo();
}