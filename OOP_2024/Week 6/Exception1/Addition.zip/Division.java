

public class Division extends BinaryExpression {

    public Division(Expression left, Expression right) {
        super(left, right);
    }

    @Override
    public String toString() {
        return left.toString() + " / " + right.toString();
    }

    @Override
    public double evaluate() {
        try {
            double rightValue = right.evaluate();
            if (rightValue == 0) {
                throw new ArithmeticException("Lỗi chia cho 0"); // Tự tạo thông báo lỗi
            }
            return left.evaluate() / right.evaluate();
        } catch (ArithmeticException e) {
            System.out.println("Lỗi chia cho 0");
            return Double.NaN;
        }

    }

}
