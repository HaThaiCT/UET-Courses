

public class Division extends BinaryExpression {

    public Division(Expression left, Expression right) {
        super(left, right);
    }

    @Override
    public String toString() {
        return left.toString() + "/" + right.toString();
    }

    @Override
    public double evaluate() {
        try {
             return left.evaluate() / right.evaluate();
        } catch (ArithmeticException e) {
            System.out.println("Lỗi chia cho 0");
            return 0;
        }
    }

}
