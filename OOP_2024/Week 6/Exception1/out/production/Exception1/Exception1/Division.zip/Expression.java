

public abstract class Expression {
    public abstract String toString();

    public abstract double evaluate();

}