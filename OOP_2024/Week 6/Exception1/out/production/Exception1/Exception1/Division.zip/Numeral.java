

public class Numeral extends Expression {
    private double value;

    public Numeral() {
        value = 0.0;
    }

    public Numeral(double value) {
        this.value = value;
    }

    public String toString() {
        return Double.toString(value);
    }

    public double evaluate() {
        return value;
    }
}