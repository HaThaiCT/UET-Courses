

public class Numeral extends Expression {
    private double value;

    public Numeral() {
        value = 0.0;
    }

    public Numeral(double value) {
        this.value = value;
    }

    public String toString() {
        return Interger.toString((int)value);
    }

    public double evaluate() {
        return value;
    }
}