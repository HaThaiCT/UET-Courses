public class BankException extends Exception {

    /**
     * ht.
     * @param message 1
     */
    public BankException(String message) {
        super(message);
    }
}
